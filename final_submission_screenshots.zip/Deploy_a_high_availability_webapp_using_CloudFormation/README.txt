# Project 2 - Udagram Project. - Deploy a High-Availability Web App using CloudFormation 

### Problem Statement of Project
Your company is creating an Instagram clone called Udagram. Developers pushed the latest version of their code in a zip file located in a public S3 Bucket.

You have been tasked with deploying the application, along with the necessary supporting software into its matching infrastructure.

This needs to be done in an automated fashion so that the infrastructure can be discarded as soon as the testing team finishes their tests and gathers their results.


### supporting files
* README.md
* create.sh : Cloudformation create stack script. 
* update.sh : Cloudformation update stack script.
* network_and_server_infrastructure.yml : Udagram Project's CloudFormation script.
* network_and_server_infrastructure.json : Udagram Project's CloudFormation script parameters.
![Infrastructure-Diagram](Diagram_of_the_Udagram_App.jpeg)
* snapshots of process

### working test link
http://Udagr-WebAp-IJ9CDJWRH1BL-1528656344.us-east-1.elb.amazonaws.com